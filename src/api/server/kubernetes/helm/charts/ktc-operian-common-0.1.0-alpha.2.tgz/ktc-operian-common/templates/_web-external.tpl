{{/*
Operian web external names
*/}}

{{- define "kapsch-web-ext-audit.subdomain" -}}
{{- .Values.configmaps.frontend.webs.audit.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-audit.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-audit.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 |trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-apigateway.subdomain" -}}
{{- .Values.configmaps.frontend.webs.apigateway.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-apigateway.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-apigateway.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}


{{- define "kapsch-web-ext-manualvalidation.subdomain" -}}
{{- .Values.configmaps.frontend.webs.manualvalidation.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-manualvalidation.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-manualvalidation.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-security.subdomain" -}}
{{- .Values.configmaps.frontend.webs.security.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-security.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-security.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-transactionmanagement.subdomain" -}}
{{- .Values.configmaps.frontend.webs.transactionmanagement.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-transactionmanagement.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-transactionmanagement.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-cfg.subdomain" -}}
{{- .Values.configmaps.frontend.webs.cfg.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-cfg.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-cfg.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-crm.subdomain" -}}
{{- .Values.configmaps.frontend.webs.crm.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-crm.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-crm.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-df.subdomain" -}}
{{- .Values.configmaps.frontend.webs.df.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-df.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-df.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 63 | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-ga.subdomain" -}}
{{- .Values.configmaps.frontend.webs.ga.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-ga.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-ga.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-landing.url" -}}
{{- printf "https://%s" .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-oboconfiguration.subdomain" -}}
{{- .Values.configmaps.frontend.webs.oboconfiguration.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-oboconfiguration.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-oboconfiguration.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-vehiclemanager.subdomain" -}}
{{- .Values.configmaps.frontend.webs.vehiclemanager.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-vehiclemanager.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-vehiclemanager.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-vip.url" -}}
{{- printf "https://%s%s%s" "vip-ui" .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-monitoring.subdomain" -}}
{{- .Values.configmaps.frontend.webs.monitoring.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-monitoring.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-monitoring.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-kibana.subdomain" -}}
{{- .Values.configmaps.frontend.webs.kibana.subdomainName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kapsch-web-ext-kibana.url" -}}
{{- printf "https://%s%s%s" ( include "kapsch-web-ext-kibana.subdomain" . ) .Values.configmaps.frontend.domainNameCharSeparator .Values.configmaps.frontend.domainName | trunc 263 | trimSuffix "-" }}
{{- end }}

